export type ContextMultiplierValuesType = {
    [key: string]: number
}
