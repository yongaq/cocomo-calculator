export { GlobalStyles } from "@mui/material";
